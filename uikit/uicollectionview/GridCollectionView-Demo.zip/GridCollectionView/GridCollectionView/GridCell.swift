//
//  GridCell.swift
//  GridCollectionView
//
//  Created by Wimansha Chathuranga on 2022-12-29.
//

import UIKit

class GridCell: UICollectionViewCell {
    static let identifier = "GridCell"
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        layer.borderWidth = 0
        layer.borderColor = UIColor.red.cgColor
        layer.cornerRadius = 5
        clipsToBounds = true
        
        backgroundColor = UIColor.randomColor()
    }
    
}

extension UIColor {
    class func randomColor(randomAlpha: Bool = false) -> UIColor {
        let redValue = CGFloat(arc4random_uniform(255)) / 255.0;
        let greenValue = CGFloat(arc4random_uniform(255)) / 255.0;
        let blueValue = CGFloat(arc4random_uniform(255)) / 255.0;
        let alphaValue = randomAlpha ? CGFloat(arc4random_uniform(255)) / 255.0 : 1;

        return UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: alphaValue)
    }
}
